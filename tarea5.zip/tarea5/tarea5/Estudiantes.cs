class Estudiantes
{
    public string matricula{get; set;} = "";
    public string nombre {get; set;} = "";
    public string apellido {get; set;} = "";
    public double edad{get; set;}
    public double n1{get; set;}
    public double n2{get; set;}

    public double promedio(){
        return (n1 + n2) / 2;
    }

    public string literal(){
        var literal = "f";
        var promedio = this.promedio();
        if (promedio >= 90)
        {
            literal = "A";
        }
        else if (promedio >= 80)
        {
            literal = "B";
        }
        else if (promedio >= 70)
        {
            literal = "C";
        }

        return literal;
    }
}