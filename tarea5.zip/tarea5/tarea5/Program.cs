﻿// See https://aka.ms/new-console-template for more information
bool continuar = true;
List<Estudiantes> Estudiantes = new List<Estudiantes>();

if (System.IO.File.Exists("datos.json"))
{
    try
    {
    var json = System.IO.File.ReadAllText("datos.json");
    Estudiantes = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Estudiantes>>(json); 
    }
    catch (System.Exception)
    {
        Console.WriteLine("se a producido un error al leer el archivo datos.json");
    }
}else{
    Console.WriteLine("no existe el archivo datos.json");
}
while (continuar)
{
    proceso.Play("incio.wav");
    Console.Clear();
    Console.WriteLine(@"
    
    
    Welcome to the Sistem

    1.Agregar Estudiante
    2.Listado
    3.Modificar
    4.Eliminar
    5.Exportar
    6.Acerca de 
    7.Salir
    
    ");
    
    var opcion = op.input("elejir opcion: ");
    switch (opcion)
    {   
        case "1":
            Console.Clear();
            var student = new Estudiantes();
            proceso.Play("matricula.wav");
            student.matricula = op.input("ingrese la matricula del estudiante: ");
            proceso.Play("nombre.wav");
            student.nombre = op.input("ingrese el nombre del estudiante: ");
            proceso.Play("apellido.wav");
            student.apellido = op.input("ingrese el apellido del estudiante: ");
            proceso.Play("edad.wav");
            student.edad = op.inputDouble("ingrese la edad del  estudiante: ");
            proceso.Play("nota1.wav");
            student.n1 = op.inputDouble("ingrese la nota 1 del  estudiante: ");
            proceso.Play("nota2.wav");
            student.n2 = op.inputDouble("ingrese la nota 2 del estudiante: ");
            Estudiantes.Add(student);
            proceso.guardar(Estudiantes);
            Console.WriteLine("estudiante agregado");

        break;
        case "2":
            Console.WriteLine("listado de estudiantes: ");
            foreach (var item in Estudiantes)
            {
                Console.WriteLine(@$"
                
                Matricula: {item.matricula}
                Nombre: {item.nombre}
                Apellido: {item.apellido}
                Edad: {item.edad}
                Nota 1: {item.n1}
                Nota 2: {item.n2}
                Promedio: {item.promedio()}
                Calificacion: {item.literal()}
                ______________________________________________________________________
                ");
            }
            Console.Write("presione entrer para Continuar: ");
            Console.ReadKey();
        break;
        case "3":
            Estudiantes = proceso.modificar(Estudiantes);
        break;
        case "4":
            Estudiantes = proceso.Eliminar(Estudiantes);
        break;
        case "5":
            proceso.Exportar(Estudiantes);
        break;
        case "6":
            proceso.About();
        break;
        case "7":
            continuar = false;
            proceso.guardar(Estudiantes);
            Console.WriteLine("gracias por usar el sistema");
        break;
        
    }
}
