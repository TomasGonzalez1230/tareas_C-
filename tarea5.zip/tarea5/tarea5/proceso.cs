class proceso
{
    public static List<Estudiantes> modificar(List<Estudiantes> estudiantes){
        Console.Clear();
        Console.WriteLine("listado de estudiantes");

        var n = 0;
        foreach (var item in estudiantes)
        {
            Console.WriteLine(@$"{n} {item.matricula} {item.nombre} {item.apellido}");
            n++;
        }

        var opcion = (int)op.inputDouble("ingrese el ID del estudiantes que desea modificar");

        if (opcion >= 0 && opcion < estudiantes.Count)
        {
            var estudiante = estudiantes[opcion];
            var posible = "";

            Console.WriteLine($"La matricula actual es {estudiante.matricula} dijite la nueva matricula o precione enter para dejarla igual");
            posible = op.input("ingrese la matricula: ");
            if (posible.Length > 0)
            {
                estudiante.matricula = posible;
            }
            
            Console.WriteLine($"El nombre actual es {estudiante.nombre} dijite el nuevo nombre o precione enter para dejarla igual");
            posible = op.input("ingrese el nombre: ");
            if (posible.Length > 0)
            {
                estudiante.nombre = posible;
            }

            Console.WriteLine($"El apellido actual es {estudiante.apellido} dijite el nuevo apellido o precione enter para dejarla igual");
            posible = op.input("ingrese el apellido: ");
            if (posible.Length > 0)
            {
                estudiante.apellido = posible;
            }

            Console.WriteLine($"La edad actual es {estudiante.edad} dijite la nueva edad o precione enter para dejarla igual");
            posible = op.input("ingrese la edad: ");
            if (posible.Length > 0)
            {
                estudiante.edad = Convert.ToDouble(posible);
            }

            Console.WriteLine($"La Nota1 actual es {estudiante.n1} dijite la nueva Nota1 o precione enter para dejarla igual");
            posible = op.input("ingrese la nota1: ");
            if (posible.Length > 0)
            {
                estudiante.n1 = Convert.ToDouble(posible);
            }

            Console.WriteLine($"La Nota2 actual es {estudiante.n2} dijite la nueva Nota2 o precione enter para dejarla igual");
            posible = op.input("ingrese la nota2: ");
            if (posible.Length > 0)
            {
                estudiante.n2 = Convert.ToDouble(posible);
            }

            estudiantes[opcion] = estudiante;
            op.MotrarMensaje("estudiantes modifiado", ConsoleColor.Blue);
            proceso.guardar(estudiantes);
        }
        else
        {
            Console.WriteLine("numero no valido");   
        }
        return estudiantes;
    }

    public static void guardar(List<Estudiantes> estudiante){
        var json = Newtonsoft.Json.JsonConvert.SerializeObject(estudiante);
        System.IO.File.WriteAllText("datos.json", json);
    }    

    public static List<Estudiantes> Eliminar(List<Estudiantes> estudiantes){
        Console.Clear();
        
        Console.WriteLine("Listado de estudiantes");
        var n = 0;
        foreach (var item in estudiantes)
        {
            Console.WriteLine(@$"{n} {item.matricula} {item.nombre} {item.apellido}");
            n++;
        }

        var opcion = (int)op.inputDouble("Ingrese el ID del estudiante que decea eliminar: ");
        if (opcion >= 0 && opcion < estudiantes.Count)
        {
            estudiantes.RemoveAt(opcion);
            Console.WriteLine($"estudiante eliminado");
            proceso.guardar(estudiantes);
        }
        return estudiantes;
    }

    public static void Exportar(List<Estudiantes> estudiantes){
        Console.WriteLine("Exportar datos");

        var filas = "";

        foreach (var item in estudiantes)
        {
            filas += @$"
            
                <tr>
                    <td>{item.matricula}</td>
                    <td>{item.nombre}</td>
                    <td>{item.apellido}</td>
                    <td>{item.n1} 1</td>
                    <td>{item.n2} 2</td>
                    <td>{item.promedio()}</td>
                    <td>{item.literal()}</td>
                </tr>
                

            ";
        }


        var html = @$"
        
            <html>
                <header>
                    <title>
                        CRUD De Estudiantes
                    </title>
                    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor' crossorigin='anonymous'>


                </header>
                <body>
                    <div class='container'>
                        <h2>LISTADO DE ESTUDIANTES</h2>
                        <div class='row'>
                            <table class='table table-dark table-striped'>
                                <thead>
                                    <tr>
                                        <th>Matricula</th>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Nota 1 </th>
                                        <th>Nota 2</th>
                                        <th>Promedio</th>
                                        <th>Literal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filas}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </body>
            </html>
        
        ";
    
        System.IO.File.WriteAllText("datos.html", html);

        var uri = "datos.html";
        var psi = new System.Diagnostics.ProcessStartInfo();
        psi.UseShellExecute = true;
        psi.FileName = uri;
        System.Diagnostics.Process.Start(psi);

    }

    public static void About(){
        Console.WriteLine(@"
        
            Este programa fue HEcho por:


            NOmbre: Tomas Gonzalez
            Email: tomasgonzalez1230@outlook.com
            
            
            para mas imformacion contate al: 829-806-0652

        ");
    }

    public static void Play(string audio){
        audio = @$"audios/{audio}";
        System.Diagnostics.Process.Start(@"powershell", $@"-c (New-Object Media.SoundPlayer '{audio}').PlaySync();");
    }
}