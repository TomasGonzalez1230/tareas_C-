class op
{
    public static string input(String msm){
        Console.Write(msm);
        return Console.ReadLine()??"";
    }

    public static double inputDouble(String msm){
        Console.Write(msm);
        double n = 0;
        while (!double.TryParse(Console.ReadLine(), out n))
        {
            MotrarMensaje("ingrse un numero validp", ConsoleColor.Red);        
        }
        return n;
    }
    public static void MotrarMensaje(String msm, ConsoleColor color){
        Console.ForegroundColor = color;
        Console.WriteLine(msm);
        Console.ResetColor();
        Console.WriteLine("Presiona enter para cotinuar...");
    }
}