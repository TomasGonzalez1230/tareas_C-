﻿// See https://aka.ms/new-console-template for more information
bool continuar = true;
while (continuar)
{    
    Console.WriteLine(@"

        ,     ,
        (\____/)
        (_oo_)
          (O)
        __||__    \)
    []/______\[] /
    / \______/ \/
    /    /__\
    (\   /____\

");
    Console.WriteLine("pregunte lo que decea saber o precion 'X' para salir:");

    var pregunta = Console.ReadLine()??"";

    if (pregunta.ToLower() == "x")
    {
        continuar = false;
        Console.WriteLine("Hasta luego :)");
    }
    else
    {
        var respuesta = op.pensar(pregunta);
        Console.WriteLine(respuesta);
        Console.WriteLine("Presiona enter para continuar");
        Console.ReadKey();
    }


}


