class op
{
    public static string Nombre = "";
    

    public static string pensar(string pregunta)
    {
        pregunta = pregunta.ToLower();

        var respuesta = "no entendi tu respuesta";

        if(pregunta.Contains("materias") || (pregunta.Contains("carreras") && pregunta.Contains("itla")))
        {
            return respuesta = @"

                las Carreras que impare el Itla son:

                1-  Simulaciones interactivas y videojuegos.
                2-  Telecomunicaciones.
                3-  Inteligencia artificial.
                4-  Informatica Forense.
                5-  Energias Renovables.
                6-  Redes de Informatica.
                7-  Mecatronica.
                8-  Manufactura Automatizada.
                9-  Manufactura de Dispositivos Medicos.
                10- Diseño Industrial.
                11- Multimedia.
                12- Sonido.
                13- Desarrollo de Software.
                14- Analitica y Ciencia de los Datos.
                15- Seguridad Informatica
            ";
        }
        else if(pregunta.Contains("Simulaciones interactivas y videojuegos"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Desarrollo de Simulaciones Interactivas y Videojuegos, obtendrás los conocimientos en Programación; Marketing; Diseño Vectorial; Matemática; Programación Orientada a Objetos; Planeamiento de Negocios; Inteligencia Artificial; Guión y Storyboard; Modelado 3D; Marketing de Videojuegos; Arte Conceptual; Dibujo Técnico; Planificación lógica y estratégica; Animación 2D y 3D; Manipulación de imagen y sonido; Game design; Testeo; Realidad virtual; Captura de movimiento y todo lo necesario para llevar los proyectos desde el borrador inicial hasta su concreción final, listos para ser distribuidos.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Guionista: El guion es un elemento que no puede faltar y es aquí donde el trabajo del guionista empieza. Un guionista de videojuegos se encarga de desarrollar la historia, los personajes y los diálogos
                    
                    Artista: Los artistas de videojuegos son, junto a los programadores, algunos de los profesionales más demandados en la industria. Un artista de videojuegos se encargará de traer “a la vida” aquel personaje y entorno imaginado por el guionista. Para esto utilizará el arte en 2D, las texturas, los modelos 3D y las animaciones de dichos personajes y entornos
                    
                    Programador: Los programadores trabajan con los elementos que los artistas han generado, sin embargo, hay diversos tipos de programadores y todos tiene una especialidad distinta. Existen programadores dedicados a la programación gráfica, programación del motor, programación de física, programación de inteligencia artificial y más

                    Compositor: Músicos que se dedican a la creación de la banda sonora de cada uno de los videojuegos

                    Ingeniero de Audio: Un ingeniero de audio es el encargado de crear los sonidos y ambientes en los que los personajes de los videojuegos se mueven. Es probablemente uno de los trabajos menos reconocidos y sin embargo son esenciales para crear un buen videojuego
            ";
        }
        else if(pregunta.Contains("Telecomunicaciones"))
        {
            return respuesta =  @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Telecomunicaciones serás capaz de diseñar, implementar y gestionar sistemas de telecomunicaciones; instalar, operar y mantener equipos electrónicos relacionados con sistemas de información y telecomunicación. Además, podrás dar soporte y mantenimiento a sistemas, determinar los requerimientos para la instalación y funcionamiento de redes de telecomunicación, ofrecer consultorías y ejecutar proyectos de telecomunicaciones. Esta carrera está orientada a la resolución de problemas contemporáneos, adaptándose a escenarios cambiantes, con alto sentido innovador y apegándose a los principios éticos y legales de la profesión.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Técnico de Campo – instalación de infraestructura de comunicaciones en campo
                    
                    Técnico de Soporte – ayuda y soporte a usuarios
                    
                    Técnico de Red – instalación y configuración de redes de datos
                    
                    Técnico de Tecnologías TIC – administración y configuración de todos los equipos de tecnologías de información y comunicaciones en una organización
                    
                    Técnico de Proyecto – dirección y ejecución de proyectos de telecomunicaciones
                    
                    Técnico Experto – tareas de peritajes sobre telecomunicación
            ";
        }
        else if(pregunta.Contains("Inteligencia artificial"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Informatica Forense"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Energias Renovables"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Redes de Informatica"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Mecatronica"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Manufactura Automatizada"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Manufactura de Dispositivos Medicos"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Diseño Industrial"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Multimedia"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Sonido"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al concluir el Tecnólogo en Inteligencia Artificial, tendrás la capacidad de modelar, diseñar y desarrollar sistemas de comportamiento inteligente, a fin de resolver problemas reales y retos que se puedan presentar en tus ámbitos laborales y de desarrollo profesional, guiados por la curiosidad, la pasión, la integridad, el trabajo en equipo y el mejoramiento continuo.

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analista de Datos
                    
                    Analista en Machine Learning
                    
                    Consultor en Minería de Datos
                    
                    Desarrollador en IA
                    
                    Consultor en IA
                    
                    Docente en IA
            ";
        }
        else if(pregunta.Contains("Desarrollo de Software"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                   Al concluir el Tecnólogo en Desarrollo de Software conocerás todas las etapas que intervienen en el proceso de desarrollo de software, enfocándose en la práctica de las tareas más técnicas.

                    Estarás capacitado para aplicar los conocimientos, técnicas, habilidades y herramientas modernas de la disciplina para las actividades de tecnología de ingeniería en sentido estricto

                Campo ocupacional
                    Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Analistas de Sistemas
                    
                    Diseñador de Software
                    
                    Desarrollador de Software
                    
                    Analista de Calidad de Software
                    
                    Analista de Base de Datos
                    
                    Administrador de Base de Datos
                    
                    Desarrollador de Aplicaciones Móviles
                    
                    Desarrollador de Página Web
                    
                    Desarrollador de Base de Datos
                    
                    Auditores de Sistemas Informáticos
                    
                    Gerente de Desarrollo de Software
                    
                    Analistas de minería de datos
                    
                    Soporte de sistemas informáticos
            ";
        }
        else if(pregunta.Contains("Analitica y Ciencia de los Datos"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                   Al finalizar el Tecnólogo en Analítica y Ciencia de los datos contarás con competencias para manejar de las técnicas y herramientas aplicables a la analítica de datos con el objetivo de proponer soluciones basadas en evidencias y ser aplicadas en el mercado local e internacional.

                    Podrás crear sistemas de información automatizados para la toma de decisiones, administrar bases de datos, diseñar y aplicar modelos y algoritmos para extraer conocimiento de valor a partir de dichos datos, analizar los datos para identificar patrones y tendencias e interpretar los datos para descubrir soluciones y oportunidades.

                Campo ocupacional
                   Como egresado de este tecnólogo podrás desempeñarte en el desarrollo de las siguientes actividades:

                    Gobierno electrónico

                    Datos abiertos
                    
                    Internet de las cosas
                    
                    Seguridad ciudadana
                    
                    Sector Energía
                    
                    Sector minería
                    
                    Sector transporte
                    
                    Biotecnología
                    
                    Control de fraude
                    
                    Sector salud pública de precisión
                    
                    Sector económico y financiero
                    
                    Analítica de multimedio
                    
                    Mercadeo digital
            ";
        }
        else if(pregunta.Contains("Seguridad Informatica"))
        {
            return respuesta = @"
                ¿Qué aprenderás?
                    Al completar el plan de estudios de manera exitosa serás capaz de:

                    Planificar, diseñar, implementar y administrar arquitecturas de ciberseguridad de acuerdo con las necesidades globales actuales, desempeñando sus funciones con un enfoque sólido de resolución de problemas complejos; siendo versátil, con actitud innovadora, ética, y de liderazgo.

                Campo ocupacional
                    
                    Analista de Redes
                    
                    Administrador de Redes
                    
                    Soporte Técnico
                    
                    Soporte de Redes
                    
                    Administrador de Sistemas
                    
                    Analista de Redes
                    
                    Analista de Seguridad
                    
                    Coordinador de Seguridad de la Información
                    
                    Analista de Vulnerabilidades
                    
                    Auditor de seguridad
                    
                    Gestor de proyectos de seguridad Informática
            ";
        }
        else if(pregunta.Contains("rector"))
        {
            return respuesta = @"
                El rector del Instituto Tecnológico de las Américas (ITLA), Omar Méndez Lluberes, reveló que el Gobierno dominicano está desarrollando un sistema que permitirá enlazar todas las instituciones del Estado bajo un mismo programa.
            ";
        }
        else if(pregunta.Contains("amadis"))
        {
            return respuesta = @"
                Amadis es un profesor del Itla
            ";
        }
        else if(pregunta.Contains("autor"))
        {
            return respuesta = @"
                El creador de este programa fue:

                Nombre: Tomas Gonzalez
                carrera: Desarrollo de Software
                Especialidad: PHP/Laravel
                correo: tomasgonzalez1230@outlook.com
                numero: 829-806-0652
            ";
        }
        else if(pregunta.Contains("dia") || pregunta.Contains("hoy") )
        {
            DateTime thisDay = DateTime.Today;
            
            Console.WriteLine(thisDay.ToString());
            Console.WriteLine();
            
            Console.WriteLine(thisDay.ToString("d"));
            Console.WriteLine(thisDay.ToString("D"));
            Console.WriteLine(thisDay.ToString("g")); 
        
            
        }
        
        else if(pregunta.Contains("hora"))
        {
            string hora = DateTime.Now.ToString("hh:ss:mm tt");
            return hora;
        }
        else if(pregunta.Contains("encuentra") && pregunta.Contains("itla") || pregunta.Contains("llegar"))
        {
            return respuesta = @"
                EL itla se encuetra en:
                Las Américas Highway, Km. 27, La Caleta, Calle 27, 1160
            ";
        }
        else if(pregunta.Contains("nota"))
        {
            return respuesta = @"
                el estudiantes sacara una C
            ";
        }
        else if(pregunta.Contains("llegar") && pregunta.Contains("itla"))
        {
            return respuesta = @"
                comprado los tike de la guagua o si no llegando en una guagua que valla campo lindo y te deja en la misma puesta del itla :)
            ";
        }
        else if(pregunta.Contains("nombre") || pregunta.Contains("llamo"))
        {
            return respuesta = @"
                tu nombre es Tomas Gonzalez
            ";
        }
        return respuesta;
    }
}