﻿// See https://aka.ms/new-console-template for more information
Console.Clear();
string option = "";
bool continuar = true;
while (continuar == true)
{
Console.WriteLine(@"

tarea C#
SELECCIONA LA OPCION QUE QUIERES VISUALIZAR

1-ACERCA DE  
2-ALGORITMOS
3-SUMADORA
4-END

");
Console.Write("INGRESE EL NUMERO DE LA OPCION QUE DECEA VISUALIZAR: ");
option = Console.ReadLine()??"";
// while (continuar == true)
// {
    if (option == "1")
    {
        Console.Clear();
        Console.Write(@"
                                            )                              
        *   )                         *   )  ( /(           (               )  
        ` )  /(        )       )      ` )  /(  )\())   (    ( )\    (      ( /(  
        ( )(_))(     (     ( /(  (    ( )(_))((_)\   ))\   )((_)  ))\ (   )\()) 
        (_(_()) )\    )\  ' )(_)) )\  (_(_())  _((_) /((_) ((_)_  /((_))\ (_))/  
        |_   _|((_) _((_)) ((_)_ ((_) |_   _| | || |(_))    | _ )(_)) ((_)| |_   
        | | / _ \| '  \()/ _` |(_-<   | |   | __ |/ -_)   | _ \/ -_)(_-<|  _|  
        |_| \___/|_|_|_| \__,_|/__/   |_|   |_||_|\___|   |___/\___|/__/ \__|  


        NAME: Tomas
        APELLIDO: Gonzalez 
        EMAIL: toamsgonzalez1230@outlook.com
        TELLL: (829)-806-0652
                                PRESIONE ENTER PARA CONTINUAR                                                                   
        ");
        Console.ReadKey();  
    }
    else if (option == "2")
    {
        Console.Clear();
        algoritmo.menu();
    }
    else if (option == "3")
    {
     int n1 = 0;
     int n2 = 0;
     Console.WriteLine("Calculadora para Sumar 2 valores");
     Console.Write("Ingrese el Primer numero: ");
     int.TryParse(Console.ReadLine(), out n1);   
     Console.Write("Ingrese el Primer numero: ");
     int.TryParse(Console.ReadLine(), out n2);
    //  continuar = false; 
     Console.WriteLine("El resulatado es " + (n1+n2));
    Console.WriteLine("Presiona ENTER para continuar");    
    Console.ReadKey();
    }
    else if (option == "4")
    {
        continuar = false;  
        Console.Clear();
        Console.Write(@"
      _  _            _       _    ___                                    
    ,'_)(_)          ( )     ( )  (   )                                   
    | |  _  ____    _| | ___ | |  | O  |__  ___  __  __  ___  __  __  ___ 
    ( _)( )( __ )  / o )( o_)( )  ( __/( _)( o )/o )( _)( o )( _`'_ )( o )
    /_\ /_\/_\/_\  \___\ \(  /_\  /_\  /_\  \_/ \__\/_\ /_^_\/_\`'/_\/_^_\
                                             _|/                      
        ");

    }else{
        Console.WriteLine("Debe elegir una opcion... Presione en ENTER para continuar");
        Console.ReadKey();
    }
}


