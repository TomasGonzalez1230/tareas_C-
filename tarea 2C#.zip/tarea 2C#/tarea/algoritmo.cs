class algoritmo
{
    public static void menu(){
        String option = "";
        Console.WriteLine("Seleccione el algoritmo que quiere ver: ");
        Console.WriteLine(@"
        1.Llegar de tu casa a bahía de las Aguilas
        2.Preparar un sancocho
        3.Como aprender a montar bicicleta
        4.Sumar 2 números.
        5.Como cambiar el aceite de un vehículo de motor.
        6.Llegar a ser senador en de RD.
        7.Como desarrollar un algoritmo.
        8.Como llegar al itla desde tu casa.
        9.Como preparar una yaroa de papas con pollo. 
        10.Comprar una laptop en internet
        ");
        Console.Write("Elija el Algoritmo que quiere ver: ");
        option = Console.ReadLine()??"";
        if (option == "1")
        {
            ag1();
        }
        else if (option == "2")
        {
            ag2();
        }
        else if (option == "3")
        {
            ag3();
        }
        else if (option == "4")
        {
            ag4();
        }
        else if (option == "5")
        {
            ag5();
        }
        else if (option == "6")
        {
            ag6();
        }
        else if (option == "7")
        {
            ag7();
        }
        else if (option == "8")
        {
            ag8();
        }
        else if (option == "9")
        {
            ag9();
        }
        else if (option == "10")
        {
            ag10();
        }else{
            Console.WriteLine("el algoritmo ingresado no existe");
        }
    }
    public static void ag1(){
        Console.WriteLine(@"
        ALGORITMO:  bahia_aguilas.

        Inicio
        1.montarte en tu vehiculo(SI TIENE: seguir al paso 2, NO: ir al paso 5)
        2.poner la ruta en el google maps
        3.llenar el tanque de combustible.
        4.llegar
        5.coger un tour hacia alla.
        6.comprar el ticket.
        7.motanrse
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag2(){
        Console.WriteLine(@"
        ALGORITMO: Sancocho.

        Inicio
        1.Calienta el aceite y sofríe las ruedas de longaniza hasta que estén doradas. Reserva.
        2.Sofríe el pollo hasta que esté dorado. Reserva.
        3.Sofríe los pedacitos de chuleta junto a la cebolla y el ají cubanela.
        4.Cuando la cebolla esté translúcida incorpora el ajo y el Sazón Completo Maggi®. Cocina por 3 a 5 minutos.
        5.Añade el agua junto a las hojas de laurel, el apio, 1 cucharada de sal y 1 cucharadita de pimienta.
        6.Cuando comience a hervir adiciona la yuca, las yautías, las zanahorias, los plátanos verdes y la auyama.
        7.Cuando el caldo retome el hervor reduce el fuego a medio bajo, incorpora el maíz las hojas de cilantro, la longaniza, el pollo, los bollitos de plátano. Rectifica sal y pimienta y cocina hasta que los víveres estén blandos y el caldo ligeramente espeso.
        8.Para hacer los bollitos:
        9.Combina el plátano rallado con la mantequilla. Sazona con sal y forma los bollitos con la ayuda de una cuchara.
        10.Reserva o incorpora directamente a cucharas en la mezcla.
        11.Espera la coccion.
        12.Servir
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag3(){
        Console.WriteLine(@"
        ALGORITMO: Montar_bicicleta

        Inicio
        1.temer una bicicleta.
        2.subirse a ella.
        3.usar ruditas de ayuda.
        4.pedaliar.
        5.cuando te sientas confiado quitar las rueditas.
        FIn
                ");
        Console.ReadKey();
    }
    public static void ag4(){
        Console.WriteLine(@"
        ALGORITMO: sumar.

        Inicio
        1. Elija su primer numero.
        2. Elija su segundo numero.
        3. Incrimente el primero nuemero las veces que el segundo le pida.
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag5(){
        Console.WriteLine(@"
        ALGORIMO:  Cambiar_aceite

        Inicio
        1.comprar el aceite correcto para el motor
        2. Eleva el vehículo de ser necesario
        3. Busca el tapón de vaciado de aceite
        4. Cambia el filtro del aceite
        5. Añade el nuevo aceite
        6. Verifica el funcionamiento
        7. Desecha el aceite viejo y aséate. 
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag6(){
        Console.WriteLine(@"
        ALGORITMO: Senador.

        Inicio
        1.ser ciudadano dominicano.
        2.tener mas de 30 años.
        3.postularce como senador
        4.ser natural de la provincia que se postulo
        5.espera a la eleccion
        6.ganar
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag7(){
        Console.WriteLine(@"
            ALGORITMO: Como_hacer_un_Algoritmo,

        Inicio
        1.analizar el problema
        2.llegar a una solucion
        3.hacer los pasos corespondiente a esa solucion
        4.probar el programa
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag8(){
        Console.WriteLine(@"
        ALGORITMO: Llegar_itla.

        Inicio
        1.asegurarse de tener el ticket de bus (SI TIENE TICKET: ir al parso 2 NO: ir al paso 5)
        2.ir a la para corespondiente.
        3.esperarlo.
        4.montarse.
        5.ir a la sabana larga.
        6.coger una campo lindo
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag9(){
        Console.WriteLine(@"
        ALGORITMO: Yaroa_Pollo.

        Inicio
        1.herbir las papas las papas.
        2.freir las papas.
        3.hecharle sal a las papas.
        4.cocinar el pollo.
        5.hechar las papas en el plato.
        6.hechar el pollo en el plato.
        7.capchu(opcional)
        8.mayonesa(opcional)
        9.comer
        Fin
        ");
        Console.ReadKey();
    }
    public static void ag10(){
        Console.WriteLine(@"
        ALGORITMO: Comprar_Laptop.

        Inicio
        1.entrar al sitio web de comprar preferido.
        2.buscar el modelo que te guste.
        3.elegir la que se acomode a tu precio.
        4.hacer el pedido.
        5.esperar que te llege.
        Fin
                ");
        Console.ReadKey();
    }
}