﻿// See https://aka.ms/new-console-template for more information
// using op;
Boolean continuar = true;
var option = "";
while (continuar)
{
    Console.Clear();
    Console.WriteLine(@"
        1.Aceptar 2 números, calcula la multiplicación de los mismos.
        2.Aceptar 2 números y calcular el promedio.
        3.Aceptar 2 catetos y encontrar la hipotenusa. 
        4.Aceptar 1 cateto e hipotenusa, encontrar el cateto faltante.
        5.Aceptar Base y altura de un triangulo, encontrar el area.
        6.Aceptar, a, b y c. Encontrar el valor de x1 y x2 segun la formula de ecuaciones de segundo grado. 
        7.Aceptar una frase. Indicar la cantidad de caracteres que tiene la misma. 
        8.Aceptar una cantidad de dinero, indicar cuantas veces se puede viajar en el metro con ese dinero usando tickets de viajero (35).
        9.Para hacer una hamburguesa se necesita 1 pan, 2 carnes, 1/5 de libra de tocineta. Calcule cuantas haburguesas se pueden hacer segun la cantidad de estas materias primas que existen en un almacén. 
        10.Programa que acepte una cantidad de dinero en pesos. Calcule cuanto es ese monto en dolares. 
        11.Programa que acepte un numero y mostrar: la mitad, el cuadrado, el doble.
        12.Programa que acepte la cantidad de energía que consume una casa al mes, calcule segun la tasa de su hogar, cuanto debera pagar esa persona por dicho consumo.
        13.Programa que acepte la fecha de nacimiento de una persona. Determine la edad de la misma. 
        14.Programa que acepte una temperatura en grados cercius, mostrarla en grado farenheight y kelvin
        15.Programa que acepte la cantidad de km por galón que da un vehículo de gasolina y la distancia a recorrer. Calcular que cantidad de dinero se gastaría en un viaje digitado estos datos al precio de esta semana de la gasolina en RD. Al principio del programa muestre a como este combustible.
        16.Realiza un un video explicando el programa que mas te gusto de la tarea 3, solo es un programa que explicaras. El video debe ser con tu voz y rostro incluido en el mismo.
    ");
    Console.Write("Elija una opcion: ");
    option = Console.ReadLine();   
    if (option == "1"){
        Console.Clear();
        op.op1();
        Console.ReadKey();
    }else if (option == "2"){
        op.op2();
        Console.ReadKey();
    }
    else if (option == "3"){
        op.op3();
        Console.ReadKey();
    }
    else if (option == "4"){
        op.op4();
        Console.ReadKey();
    }
    else if (option == "5"){
        op.op5();
        Console.ReadKey();
    }
    else if (option == "6"){
        op.op6();
        Console.ReadKey();
    }
    else if (option == "7"){
        op.op7();
        Console.ReadKey();
    }
    else if (option == "8"){
        op.op8();
        Console.ReadKey();
    }
    else if (option == "9"){
        op.op9();
        Console.ReadKey();
    }
    else if (option == "10"){
        op.op10();
        Console.ReadKey();
    }
    else if (option == "11"){
        op.op11();
        Console.ReadKey();
    }
    else if (option == "12"){
        op.op12();
        Console.ReadKey();
    }
    else if (option == "13"){
        Console.Write("tu edad es: {0}",op.op13());
        Console.ReadKey();
    }
    else if (option == "14"){
        op.op14();
        Console.ReadKey();
    }
    else if (option == "15"){
        op.op15();
        Console.ReadKey();
    }
    else if (option == "16"){
        var uri = "https://youtube.com/shorts/Y_ohTutilok";
        var psi = new System.Diagnostics.ProcessStartInfo();
        psi.UseShellExecute = true;
        psi.FileName = uri;
        System.Diagnostics.Process.Start(psi);
    }else
    {
        Console.WriteLine("opcion no validada");
    }
}

