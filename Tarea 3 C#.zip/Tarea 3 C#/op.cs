class op
{
    public static void op1(){
        int n1 = 0; 
        int n2 = 0;
        int r = 0;
        Console.WriteLine("Aceptar 2 números, calcula la multiplicación de los mismos.");
        n1 = Inputnumber("ingrese un numero: ");
        n2 = Inputnumber("ingrese otro numero: ");
        r = n1 * n2;
        Console.Write("el resultado es: {0}", r);
        
    }
    public static void op2(){
        double n1 = 0;
        double n2 = 0;
        double r = 0;
        Console.WriteLine("Aceptar 2 números y calcular el promedio");
        n1 = Inputnumber("ingrese un numero: ");
        n2 = Inputnumber("ingrese otro numero: ");
        r = (n1 + n2) / 2;
        Console.Write("el resultado es {0}", r);
    }
    public static void op3()
    {
        double n1 = 0;
        double n2 = 0;
        double x = 0;
        double r = 0;
        Console.WriteLine("Calcular la Hipotenusa");
        n1 = Inputnumber("ingrese el primer cateto: ");
        n2 = Inputnumber("ingrese el segundo cateto: ");
        x = Math.Pow(n1, 2) + Math.Pow(n2, 2);
        r = Math.Sqrt(x);
        Console.Write("La hipostenusa es: {0}",r);
    }
    public static void op4()
    {
        double n1 = 0;
        double n2 = 0;
        double x = 0;
        double r = 0;
        Console.WriteLine("Calcular el cateto");
        n1 = Inputnumber("ingrese el primer cateto: ");
        n2 = Inputnumber("ingrese la hipotenusa: ");
        x = Math.Pow(n2, 2) - Math.Pow(n1, 2);
        if (n1>n2)
        {
            Console.WriteLine("La hipotenusa debe ser mas grande que el cateto");
        }else
        {
            r = Math.Sqrt(x);
        }
        Console.Write("El area del triangulo es: {0}", r);

        
    }
    public static void op5()
    {
        double n1 = 0;
        double n2 = 0;
        double x = 0;
        
        Console.WriteLine("Calcular area de un triangulo");
        n1 = Inputnumber("ingrese la base: ");
        n2 = Inputnumber("ingrese la altura: ");
        x = (n1 * n2) / 2;

        Console.Write("El area del triangulo es: {0}", Math.Round(x));
        
    }
    public static void op6()
    {
        double a ,b ,c ,x1,x2;
        
        Console.WriteLine("Ecuacion de segundo grado");
        a = Inputnumber("ingrese a: ");
        b = Inputnumber("ingrese b: ");
        c = Inputnumber("ingrese c: ");
        x1 = (-b+(Math.Sqrt(Math.Pow(b,2)-4*a*c)))/(2*a);
        x2 = (-b-(Math.Sqrt(Math.Pow(b,2)-4*a*c)))/(2*a);
        if(x2.ToString() == "NaN" || x1.ToString() == "NaN") 
        {
			Console.WriteLine("no real roots");
		}
        else if(x1 != x2) 
        {
			Console.WriteLine("{0:0.00}",x2);
			Console.WriteLine("{0:0.00}",x1);
		}
        else 
        {
			Console.WriteLine("{0:0.00}",x1);
		}
    }
    public static void op7(){
        Console.WriteLine("saver la logintud de una cadena");
        Console.Write("introdusca la cadena: ");
        string cadena = Console.ReadLine()??"";
        Console.WriteLine("la longitud de la cadena es {0}",cadena.Length);
    }
    
    public static void op8(){
        int vueltas,monto;
        vueltas = 0;
        monto = 0;
        Console.WriteLine("veces que puedes viajar en metro");
        monto = Inputnumber("cuanto tines: ");
        while (monto>=35)
        {
            monto -= 35;
            vueltas ++;
        }
        Console.WriteLine("puedes viajar "+ vueltas);
    }
    
    public static void op9(){
        int pan, carne, tocineta, hambur;
        hambur = 0;
        pan = Inputnumber("pan: ");
        carne = Inputnumber("carne: ");
        tocineta = Inputnumber("tocineta: ");
        while (pan >= 1 && carne >= 2 && tocineta >= 1/5)
        {
            hambur += 1;
            pan -=1 ;
            carne -=2 ;
            tocineta -=1/5 ;
        }
            Console.Write("tines {0} hamburguesas", hambur);
        //else
        // {
        //     Console.WriteLine("te faltan ingredientes para la hamburguesa");
        // }
    }

    public static void op10(){
        double peso,dolar;
        Console.WriteLine("convertir de peso a dolar");
        peso = Inputnumber("peso domincano");
        dolar = (peso * 0.018);
        Console.Write("cantidad en dolares {0}", dolar);
    }

    public static void op11(){
        double mitad,cuadrado,doble;
        int monto = Inputnumber("introduce el numero: ");
        mitad = monto / 2;
        cuadrado = Math.Pow(monto,2);
        doble = monto * 2;
        Console.Write(@"
            la mitad el numero es {0}
            el cuadrado del numero es {1}
            el doble del numero es {2}
        ",mitad, cuadrado, doble);
    }

    public static void op12(){
        double KWH = Inputnumber("cuantos KWH consumio en el mes: ");
        double consumo = KWH * 0.093;
        Console.WriteLine("el precio a pagar este mes es {0}",consumo);
    }

    public static int op13()
        {
            
            DateTime fechaActual = DateTime.Today;
            Console.Write("introdusca la fecha de nacimiento: ");
            DateTime fechaNacimiento = DateTime.Parse(Console.ReadLine()??"");
            
            if (fechaNacimiento > fechaActual)
            {
                Console.WriteLine ("La fecha de nacimiento es mayor que la actual.");
                return -1;
            }
            else 
            {
                int edad = fechaActual.Year - fechaNacimiento.Year;
                
                
                if (fechaNacimiento.Month > fechaActual.Month)
                {
                    --edad;
                }
                
                return edad;
            }
        }

    public static void op14(){
        int celsius = Inputnumber("intrusca los grados celsius: ");
        double kelvin = celsius * 273.15;
        double farenheight = (celsius * 9/5) + 32;
        Console.WriteLine(@"
        grados kelvin {0}
        grados farenheight {1}
        ",kelvin, farenheight);
    }
    
    public static void op15(){
        Console.WriteLine("precio del combustible: $274.50");
        double precio = 275.50;
        double distancia = Inputnumber("cuantos KM vas a recorrer: ");
        double rendimiento = Inputnumber("cuantos KM por galon da tu vehiculo: ");
        double total = (distancia/rendimiento) * precio;
        Console.Write("vas a Gastar {0} pesos de combustible", total);
    }
    public static int Inputnumber(String msm){
        int n = 0;
        try
        {
            Console.Write(msm);
            int.TryParse(Console.ReadLine(), out n);
        }
        catch (System.Exception)
        {
            Console.WriteLine("valor no validoL");
            n = Inputnumber(msm);
        }
        return n;
    } 


}